
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)
feedback_data = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input']
    # Simulated AI response
    response = "You can apply for a birth certificate at your municipal office or online portal."
    return render_template('index.html', user_input=user_input, response=response)

@app.route('/feedback')
def feedback():
    return render_template('feedback.html')

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    text = request.form['feedback']
    # Simulated sentiment classification
    if "good" in text.lower():
        sentiment = "Positive"
    elif "bad" in text.lower():
        sentiment = "Negative"
    else:
        sentiment = "Neutral"
    feedback_data.append({'text': text, 'sentiment': sentiment})
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    sentiments = {'Positive': 0, 'Neutral': 0, 'Negative': 0}
    for fb in feedback_data:
        sentiments[fb['sentiment']] += 1
    return render_template('dashboard.html', sentiments=sentiments)

if __name__ == '__main__':
    app.run(debug=True)
